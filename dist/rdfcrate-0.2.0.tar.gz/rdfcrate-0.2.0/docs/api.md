# API

::: rdfcrate.wrapper.RoCrate

::: rdfcrate.AttachedCrate
    members: true

::: rdfcrate.uris
    members: false

::: rdfcrate.bioschemas
    members: false

::: rdfcrate.spec_version
    options:
        members: false
        summary: true
