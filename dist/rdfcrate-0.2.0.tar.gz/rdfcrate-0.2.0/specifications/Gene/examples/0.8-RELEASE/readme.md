# Note to 0.8-RELEASE examples

The 0.8-RELEASE only introduces cardinalities for associatedDisease (MANY) and taxonomicRange (MANY) so [0.7-RELEASE examples](https://github.com/BioSchemas/specifications/tree/master/Gene/examples/0.7-RELEASE) also work for 0.8-RELEASE
