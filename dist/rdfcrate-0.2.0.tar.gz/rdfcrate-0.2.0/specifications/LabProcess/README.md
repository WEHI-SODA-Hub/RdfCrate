# LabProcess Specification

## Type

Thing > CreativeWork > [LabProcess](https://bioschemas.org/LabProcess/)

## Profile 

### Example Markup

## Issue Tracker

